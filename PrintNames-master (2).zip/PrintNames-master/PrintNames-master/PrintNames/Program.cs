﻿using System;

namespace PrintNames
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Martin Sabo");
            Console.WriteLine("Peter Volanský");
        }
    }
}
